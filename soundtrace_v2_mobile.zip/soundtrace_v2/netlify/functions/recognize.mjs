// Netlify Functions: keep AUDD_API_TOKEN server-side, never in public HTML.
export default async (request) => {
  const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});
  if(request.method!=='POST')return json({error:'POST 요청만 지원해.'},405);
  const token=Netlify.env.get('AUDD_API_TOKEN');
  if(!token)return json({error:'음악 인식 API가 아직 연결되지 않았어. Netlify 환경변수 AUDD_API_TOKEN을 설정해 줘.'},503);
  try{
    const type=request.headers.get('content-type')||'';
    if(!type.includes('multipart/form-data'))return json({error:'파일 업로드 형식이 올바르지 않아.'},400);
    const form=await request.formData();const file=form.get('file');
    if(!file||typeof file.arrayBuffer!=='function')return json({error:'오디오 파일이 필요해.'},400);
    if(file.size>4*1024*1024)return json({error:'분석용 오디오 파일은 4MB 이하만 지원해.'},413);
    const upstream=new FormData();upstream.append('api_token',token);upstream.append('return','spotify,apple_music');upstream.append('file',file,'sample.wav');
    const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),25000);
    let response;
    try{response=await fetch('https://api.audd.io/',{method:'POST',body:upstream,signal:controller.signal})}finally{clearTimeout(timeout)}
    if(!response.ok)return json({error:'음악 인식 제공업체에 연결하지 못했어.'},502);
    const data=await response.json();
    if(data.status!=='success')return json({error:'음악 인식 제공업체가 요청을 처리하지 못했어. API 키와 사용량을 확인해 줘.'},502);
    const r=data.result;
    if(!r)return json({match:null});
    return json({match:{title:r.title||null,artist:r.artist||null,album:r.album||null,release_date:r.release_date||null,song_link:r.song_link||null}});
  }catch(err){return json({error:err?.name==='AbortError'?'음악 인식 요청 시간이 초과됐어.':'음악 인식 중 서버 오류가 발생했어.'},502)}
};
export const config={path:'/.netlify/functions/recognize'};
