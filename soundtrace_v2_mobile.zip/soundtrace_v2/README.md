# SoundTrace AI V2 — 모바일 음악 인식 MVP

## 구현된 기능
- 모바일 오디오 파일 선택/재생
- 마이크 녹음 (HTTPS 필요)
- 브라우저에서 짧은 음원을 16kHz WAV로 변환
- 저장된 영상에서 오디오 추출 시도 (브라우저/코덱에 따라 실패할 수 있으며 영상 일부를 실제 시간으로 재생)
- Netlify Function을 통한 AudD 음악 인식 API 호출 (API 토큰 필수)
- 실제 인식된 곡명/아티스트/앨범/발매 정보 표시, YouTube/Spotify 검색 링크
- API 미설정, 인식 실패, 파일 문제에 대한 명시적 오류 안내

## 아직 구현하지 않은 기능
- SNS URL만으로 곡 인식
- 원곡과의 자동 정렬 및 배속·피치·리버브·에코 등 효과 비교
- 리믹스 버전의 확정 판별
- 실시간 영상 추출의 모든 안드로이드 기기/브라우저 지원
- 서버 측 사용자별 요청 제한, 계정/결제, 대규모 운영 보안

## 휴대폰에서 배포하기 (중요)
이 프로젝트는 `index.html` 단독 실행으로 음악 인식이 되지 않습니다. **Netlify Functions 배포 + AudD API 키**가 필요합니다. Netlify Drop에 ZIP만 올리는 정적 배포로는 서버 함수가 활성화되지 않을 수 있습니다.

1. 휴대폰 크롬에서 GitHub에 로그인해 새 공개/비공개 저장소를 만듭니다.
2. 저장소에 `index.html`, `netlify.toml`, `netlify/functions/recognize.mjs` 파일을 **같은 폴더 구조로** 업로드합니다. 휴대폰 브라우저의 데스크톱 사이트 모드가 필요할 수 있습니다.
3. Netlify에 로그인 → Add new project → Import an existing project → GitHub 저장소 연결.
4. 빌드 명령어는 비워 두고, 게시 디렉터리는 `.` (루트), Functions 디렉터리는 `netlify/functions`로 지정합니다.
5. AudD에서 본인 계정으로 발급받은 API 토큰을 Netlify 사이트 설정의 Environment variables에 `AUDD_API_TOKEN` 이름으로 등록합니다. 토큰을 HTML/저장소에 직접 입력하지 마세요.
6. 재배포한 뒤 생성된 `https://...netlify.app` 주소에서 음악 인식을 시험합니다.
7. 마이크 권한을 허용하고, 우선 MP3/WAV/M4A 녹음 파일로 시험하세요. 영상 추출은 기기별 호환성 차이가 있습니다.

## 데이터 및 비용
- 오디오의 최대 15초를 WAV로 변환하여 Netlify Function으로 전송하고, Function은 AudD로 전달합니다. 이 코드에서 파일을 디스크에 저장하지 않지만 제공업체의 보관 정책은 별도로 확인해야 합니다.
- AudD/Netlify 무료 사용량, 과금, 서비스 약관은 계정 및 시점에 따라 다릅니다. 가입 전 공식 요금표를 확인하세요.
- 누구나 사용할 공개 서비스로 운영하기 전에 인증, 사용량 제한, 악용 방지, 업로드 크기 제한 및 개인정보 처리 고지가 추가로 필요합니다.

## 로컬 HTML 열기
`index.html`만 열면 화면과 파일 선택/재생은 확인할 수 있으나 `/.netlify/functions/recognize` API가 없어서 곡 인식은 작동하지 않습니다.
